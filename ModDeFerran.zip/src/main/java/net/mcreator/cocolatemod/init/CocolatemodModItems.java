
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.cocolatemod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.mcreator.cocolatemod.item.DechocolateItem;
import net.mcreator.cocolatemod.item.ChocolateItem;
import net.mcreator.cocolatemod.CocolatemodMod;

public class CocolatemodModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, CocolatemodMod.MODID);
	public static final RegistryObject<Item> DECHOCOLATE_HELMET = REGISTRY.register("dechocolate_helmet", () -> new DechocolateItem.Helmet());
	public static final RegistryObject<Item> DECHOCOLATE_CHESTPLATE = REGISTRY.register("dechocolate_chestplate",
			() -> new DechocolateItem.Chestplate());
	public static final RegistryObject<Item> DECHOCOLATE_LEGGINGS = REGISTRY.register("dechocolate_leggings", () -> new DechocolateItem.Leggings());
	public static final RegistryObject<Item> DECHOCOLATE_BOOTS = REGISTRY.register("dechocolate_boots", () -> new DechocolateItem.Boots());
	public static final RegistryObject<Item> CHOCOLATE = REGISTRY.register("chocolate", () -> new ChocolateItem());
}
